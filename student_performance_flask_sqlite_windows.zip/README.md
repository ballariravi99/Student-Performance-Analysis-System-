# EduMetric - Student Performance Analysis System
### Windows Setup Instructions (Zero Database Setup Required)

1. Open Command Prompt (cmd) in this folder.
2. Create and activate virtual environment:
   python -m venv venv
   venv\Scripts\activate

3. Install packages:
   pip install -r requirements.txt

4. Run the application:
   python app.py

student_performance.db and all tables are created automatically!
Open your browser to: http://localhost:5000