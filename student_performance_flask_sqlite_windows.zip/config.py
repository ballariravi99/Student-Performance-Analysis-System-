import os
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'edumetric-academic-secret-key-2024-sqlite')
    # Local student_performance.db file (No MySQL setup needed!)
    DATABASE_PATH = os.getenv('DATABASE_PATH', os.path.join(BASE_DIR, 'student_performance.db'))
    DEBUG = os.getenv('FLASK_DEBUG', 'True').lower() in ('true', '1', 't')
    PORT = int(os.getenv('PORT', 5000))