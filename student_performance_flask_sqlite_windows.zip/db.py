import sqlite3
import os
from flask import g
from config import Config

def get_db_connection():
    if 'db' not in g:
        g.db = sqlite3.connect(Config.DATABASE_PATH, detect_types=sqlite3.PARSE_DECLTYPES)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON;")
    return g.db

def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def query_db(query, args=(), one=False, commit=False):
    conn = get_db_connection()
    try:
        cur = conn.cursor()
        cur.execute(query, args)
        if commit:
            conn.commit()
            return cur.lastrowid
        rv = cur.fetchall()
        cur.close()
        return (rv[0] if rv else None) if one else rv
    except Exception as err:
        if commit:
            conn.rollback()
        raise err

def init_db(app=None):
    conn = sqlite3.connect(Config.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    cur = conn.cursor()

    # 1. Automatically create all tables
    cur.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'teacher',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_login TIMESTAMP DEFAULT NULL
    );

    CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id TEXT NOT NULL UNIQUE,
        roll_number TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        department TEXT NOT NULL,
        semester INTEGER NOT NULL CHECK (semester BETWEEN 1 AND 8),
        email TEXT NOT NULL UNIQUE,
        phone TEXT DEFAULT NULL,
        admission_year INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS subjects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_code TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        department TEXT NOT NULL,
        semester INTEGER NOT NULL CHECK (semester BETWEEN 1 AND 8),
        credits INTEGER NOT NULL DEFAULT 3,
        max_marks INTEGER NOT NULL DEFAULT 100,
        passing_marks INTEGER NOT NULL DEFAULT 40,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS examinations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        exam_name TEXT NOT NULL,
        exam_type TEXT NOT NULL DEFAULT 'final',
        academic_year TEXT NOT NULL,
        semester INTEGER NOT NULL CHECK (semester BETWEEN 1 AND 8),
        start_date DATE DEFAULT NULL,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS marks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER NOT NULL,
        subject_id INTEGER NOT NULL,
        examination_id INTEGER NOT NULL,
        marks_obtained REAL NOT NULL,
        max_marks INTEGER NOT NULL DEFAULT 100,
        remarks TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
        FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
        FOREIGN KEY (examination_id) REFERENCES examinations(id) ON DELETE CASCADE,
        UNIQUE (student_id, subject_id, examination_id)
    );
    """)
    conn.commit()

    # 2. Insert demonstration data ONLY if students table is empty
    cur.execute("SELECT COUNT(*) AS cnt FROM students;")
    count_row = cur.fetchone()
    if count_row and count_row['cnt'] == 0:
        # Seed default users & records
        cur.execute("INSERT OR IGNORE INTO users (username, email, password_hash, full_name, role) VALUES ('admin', 'admin@edumetric.edu', 'scrypt:32768:8:1$KqJgG9q81b6e49i6$4df76e27ab35889beab86801a61c7dcf0b8aa75db6a72e8113ce0f1aa02db0b7d34199c0d381ae4ca1bce1b4bcf4daebf9b9f471ad00f074d283626e2a2a0ebc', 'Dr. Sarah Jenkins', 'admin');")
        conn.commit()
    conn.close()