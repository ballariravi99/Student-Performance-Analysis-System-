import functools
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from config import Config
from db import get_db_connection, close_db, query_db, init_db

app = Flask(__name__)
app.config.from_object(Config)
app.teardown_appcontext(close_db)

# Automatically create student_performance.db & tables on startup
with app.app_context():
    init_db(app)

def calculate_grade(percentage):
    if percentage >= 90.0:
        return 'A+', 'Outstanding', 'success'
    elif percentage >= 80.0:
        return 'A', 'Excellent', 'primary'
    elif percentage >= 70.0:
        return 'B', 'Very Good', 'info'
    elif percentage >= 60.0:
        return 'C', 'Good', 'secondary'
    elif percentage >= 50.0:
        return 'D', 'Satisfactory', 'warning'
    else:
        return 'F', 'Fail', 'danger'

def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this portal.', 'warning')
            return redirect(url_for('login', next=request.url))
        return view(**kwargs)
    return wrapped_view

@app.route('/')
@app.route('/dashboard')
@login_required
def dashboard():
    total_students_res = query_db("SELECT COUNT(*) AS total FROM students WHERE status = 'active'", one=True)
    total_students = total_students_res['total'] if total_students_res else 0

    student_perf_sql = """
        SELECT 
            s.id AS student_id,
            s.student_id AS student_code,
            s.name,
            s.roll_number,
            s.department,
            COUNT(m.id) AS subjects_evaluated,
            SUM(m.marks_obtained) AS total_obtained,
            SUM(m.max_marks) AS total_max,
            CASE WHEN SUM(m.max_marks) > 0 THEN (SUM(m.marks_obtained) * 1.0 / SUM(m.max_marks)) * 100.0 ELSE 0 END AS overall_pct,
            SUM(CASE WHEN m.marks_obtained < s_sub.passing_marks THEN 1 ELSE 0 END) AS failed_subjects_count
        FROM students s
        LEFT JOIN marks m ON s.id = m.student_id
        LEFT JOIN subjects s_sub ON m.subject_id = s_sub.id
        WHERE s.status = 'active'
        GROUP BY s.id, s.student_id, s.name, s.roll_number, s.department
        HAVING subjects_evaluated > 0
    """
    students_perf = query_db(student_perf_sql) or []
    return render_template('dashboard.html', total_students=total_students, evaluated_count=len(students_perf))

if __name__ == '__main__':
    print("Running EduMetric with embedded SQLite database student_performance.db")
    app.run(host='0.0.0.0', port=Config.PORT, debug=Config.DEBUG)